﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Funcoes
    {
        public string[,] rps_game_winner(string[,] list) //a string recebida deve ser [2,2]
        {
            string[,] result = new string[1, 2];

            // i < 2 Wrong number of Playerserror
            if (list.Length < 2)
            {
                Console.WriteLine("ERRO: WrongNumberOfPlayers");
                Console.ReadKey();
                Environment.Exit(0);
            }

            //NoSuchStrategyError
            else if ((!string.Equals(list[0, 1], "S", StringComparison.CurrentCultureIgnoreCase)
                && !string.Equals(list[0, 1], "P", StringComparison.CurrentCultureIgnoreCase)
                && !string.Equals(list[0, 1], "R", StringComparison.CurrentCultureIgnoreCase))
                || ((!string.Equals(list[1, 1], "S", StringComparison.CurrentCultureIgnoreCase)
                && !string.Equals(list[1, 1], "P", StringComparison.CurrentCultureIgnoreCase)
                && !string.Equals(list[1, 1], "R", StringComparison.CurrentCultureIgnoreCase))))
            {
                Console.WriteLine("ERRO: NoSuchStrategy");
                Console.ReadKey();
                Environment.Exit(0);
            }
            else //caso funcione
            {
                // caso jogador 2 vença    
                if ((string.Equals(list[1, 1], "S", StringComparison.CurrentCultureIgnoreCase) && (string.Equals(list[0, 1], "P", StringComparison.CurrentCultureIgnoreCase)))
                    || (string.Equals(list[1, 1], "R", StringComparison.CurrentCultureIgnoreCase) && (string.Equals(list[0, 1], "S", StringComparison.CurrentCultureIgnoreCase)))
                    || (string.Equals(list[1, 1], "P", StringComparison.CurrentCultureIgnoreCase) && (string.Equals(list[0, 1], "R", StringComparison.CurrentCultureIgnoreCase))))
                {
                    result[0, 0] = list[1, 0];
                    result[0, 1] = list[1, 1];
                }
                // se não jogador 1 ganha
                else
                {
                    result[0, 0] = list[0, 0];
                    result[0, 1] = list[0, 1];

                }

            }
             
            return result;

        }


        //funcao do torneio, vai ser recursiva
        public string[,] rps_tournament_winner(string[][,] chaveTorneio, int i)
        {
            string[,] resultado = new string[1, 2];
             
            string[,] jogo = new string[2, 2];
              
            // generico
            Console.WriteLine(i+" pessoas----------------------------------"  );
            for (int c = 0; c < i; c = c + 2)
            {

                jogo[0, 0] = chaveTorneio[c][0, 0]; // "João";
                jogo[0, 1] = chaveTorneio[c][0, 1]; // "S";
                jogo[1, 0] = chaveTorneio[c + 1][0, 0]; // "Pedro";
                jogo[1, 1] = chaveTorneio[c + 1][0, 1]; // "P";

                Console.WriteLine("Partida: " + jogo[0, 0] + " - " + jogo[0, 1] + " X " + jogo[1, 0] + " - " + jogo[1, 1]);
                resultado = rps_game_winner(jogo);
                chaveTorneio[c / 2][0, 0] = resultado[0, 0];
                chaveTorneio[c / 2][0, 1] = resultado[0, 1];
                Console.WriteLine("- Vencedor da Partida: " + resultado[0, 0] + " - " + resultado[0, 1]);

            }
             
            //chamada recursiva
            if (i > 2)
            {
                i = i / 2;
                return rps_tournament_winner(chaveTorneio, i);           

            }
            else { 
                return resultado;
            }

            
        }

        //preenche a lista do torneio
        public string[][,] preencherLista(int tamanho)
        {

            string[][,] torneio = new string[tamanho][,];

            for (int i = 0; i < tamanho; i++)
            {
                torneio[i] = new string[1, 2];
                Console.WriteLine("Por favor, preencha o nome do jogador numero " + (i + 1));
                torneio[i][0, 0] = Console.ReadLine();
                Console.WriteLine("Por favor, preencha a jogada do jogador numero " + (i + 1));
                torneio[i][0, 1] = Console.ReadLine();
            }

            return torneio;

        }

    }


    class Program
    {
        static void Main(string[] args)
        {
            Funcoes f = new Funcoes();
            int i ;

            Console.WriteLine("--Digite o numero de jogadores (que seja na potencia 2^n): ");
            i = Convert.ToInt32(Console.ReadLine());

            string[,] jogo = new string[2, 2] /*{ { "João", "R" }, {"Pedro","R" } }*/;

            string[,] resultado = new string[1, 2];
            string[][,] torneioLista = new string[i][,];


            torneioLista = f.preencherLista(i);

            resultado = f.rps_tournament_winner(torneioLista, i);
            Console.WriteLine();
            Console.WriteLine("----*----");
            Console.WriteLine("----- O VENCEDOR DO TORNEIO E:" + resultado[0, 0] +" - "+ resultado[0, 1]);
            Console.WriteLine("----*----");
            Console.WriteLine();

             
            Console.ReadKey();
        }
    }
}
